/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.thehartford.pl.mr.core.constants.HomeRateServiceConstants;
import com.thehartford.pl.mr.entity.ErrorMessageRootRefCustomEntity;

/**
 * @author ac12516
 *
 */
@Repository
@Transactional
public class ErrorMessageRootRefRepositoryImpl implements ErrorMessageRootRefRepository {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorMessageRootRefRepositoryImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * getScreenErrorDescription is an overridden method. The class
	 * ErrorMessageRootRefRepositoryImpl is an implementation of
	 * ErrorMessageRootRefRepository and takes two parameters stateAbbr and
	 * errorNarrNewCd
	 * 
	 * @param stateAbbr
	 *            is used to get the state based error code
	 * 
	 * @param errorNarrNewCd
	 *            is the screen error code that is returned in the FS response
	 * 
	 * @return a list of ErrorMessageRootRefCustomEntity for the combination of
	 *         state abbreviation and narrativecd so that we can map the
	 *         description of the error code to the final response and send it
	 *         to the user
	 * 
	 */
	
	
	/**
	 * A default constructor
	 */
	public ErrorMessageRootRefRepositoryImpl() {
			// default constructor
	}
	

	@Override
	public List<ErrorMessageRootRefCustomEntity> getScreenErrorDescription(String stateAbbr, String errorNarrNewCd) {

		Query query = entityManager.createNamedQuery("ErrorMessageRootRefCustomEntity.getScreenErrorDescription");
		// first dynamic parameter in the query is stateAbbr
		query.setParameter(1, stateAbbr);
		// second parameter in the query is errorNarrNewCd
		query.setParameter(HomeRateServiceConstants.SECOND_PARAMETER_TWO, errorNarrNewCd);
		 
		LOGGER.info("At ErrorMessageRootRefRepositoryImpl, list of entities returned by the query are {}", (List<ErrorMessageRootRefCustomEntity>) query.getResultList());
		return (List<ErrorMessageRootRefCustomEntity>) query.getResultList();
	}

	

}
