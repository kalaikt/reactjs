/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/
package com.thehartford.pl.mr.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.thehartford.pl.mr.entity.ErrorMessageRootRefCustomEntity;



@Repository
@Transactional
@FunctionalInterface

public interface ErrorMessageRootRefRepository {

	/**
	 * @param stateAbbr
	 *            is used to get the state based error code
	 * @param errorNarrNewCd
	 *            is the screen error code that is returned in the FS response0
	 * @return a list of ErrorMessageRootRefCustomEntity for the combination of
	 *         state abbreviation and narrativecd
	 */
	List<ErrorMessageRootRefCustomEntity> getScreenErrorDescription(String stateAbbr, String errorNarrNewCd);

}
