/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/
package com.thehartford.pl.mr.repository;


import com.mysema.query.BooleanBuilder;
import com.mysema.query.jpa.impl.JPAQuery;
import com.thehartford.pl.mr.core.constants.CommonConstants;
import com.thehartford.pl.mr.entity.ApplicationRestriction;
import com.thehartford.pl.mr.entity.QApplicationRestriction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @author aw94020
 * 
 * This class uses queryDSL to generate a dynamic query to search
 * the ApplicationRestriction table.  
 * */
@Repository
public class ApplicationRestrictionRepositoryImpl implements ApplicationRestrictionRepository {
	private static final Logger LOG = LoggerFactory.getLogger(ApplicationRestrictionRepositoryImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private QApplicationRestriction appRestriction;
	private BooleanBuilder conditions;
    	
    public ApplicationRestrictionRepositoryImpl(){
        //
    }

	/**
	 *   Initializes the instance needed to use queryDSl
	 * */
    @PostConstruct
	public void init() {
		appRestriction = QApplicationRestriction.applicationRestriction;
	}
    
	/**
	 *   Implementation of findByQuery method in SearchRequestRepository 
	 *   that uses these parameters to search for matching entries. 
	 *   It makes use of the private methods 
	 *   in this class to generate a dynamic query.  
	 * @param businessSegment
	 * @param partner
	 * @param operationName
	 * @param ratingState
	 * @param producerCode
	 * @param lob
	 * @param formType
	 * @return a list of entries matching the query
	 * */
	@Override
	public List<ApplicationRestriction> findByQuery(String businessSegment, String partner, String operationName,
			                                        String ratingState, String producerCode, int lob, String formType) {
		conditions = new BooleanBuilder();
		List<ApplicationRestriction> applicationRestriction = new ArrayList<>(); 
		
		try{
			JPAQuery query = new JPAQuery(entityManager);

			filterRestrictionData(businessSegment, partner, operationName, ratingState, producerCode, lob);
	        filterFormType(formType);
	        
	        conditions.and(appRestriction.effectiveDate.loe(new Date()).or(appRestriction.effectiveDate.isNull()));
	      
	        query.from(appRestriction)
	          .innerJoin(appRestriction.state)
	          .where(conditions).orderBy(appRestriction.applRstrcId.desc());
	        
	        applicationRestriction = query.list(appRestriction);
		}
		catch(Exception ex){
			LOG.error("ApplicationRestriction findByQuery: {}", ex);
		}
		
		return applicationRestriction;
	}


	/**
	 *   Accepts a String representing the formType and adds on
	 *   an and condition to the query that sets searches
	 *   for that formType.
	 *   Appends query conditions to condition variable thus allowing
	 *   for dynamic query functionality.    
     * @param formType
	 * 
	 * */
	private void filterFormType(String formType) {
		if(CommonConstants.FormType.HO3.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeHO3.eq("Y"));
        }
		else if(CommonConstants.FormType.HO4.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeHO4.eq("Y"));
		}
		else if(CommonConstants.FormType.HO5.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeHO5.eq("Y"));
		}
		else if(CommonConstants.FormType.HO6.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeHO6.eq("Y"));
		}
		else if(CommonConstants.FormType.HO7.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeHO7.eq("Y"));
		}
		else if(CommonConstants.FormType.RP3.name().contains(formType)){
			conditions.and(appRestriction.rstrcFormTypeRP3.eq("Y"));
		}
	}
	/**
	 *   Accepts 5 inputs and builds conditions for the query
	 *   based on the input's state (is it null or not).  Appends 
	 *   query conditions to condition variable thus allowing
	 *   for dynamic query functionality.    
     * @param businessSegment
	 * @param partner
	 * @param operationName
	 * @param ratingState
	 * @param producerCode
	 * @param lob
	 * */
	private void filterRestrictionData(String businessSegment, String partner, String operationName, String ratingState,
			String producerCode, int lob) {
		if(ratingState != null){
             conditions.and(appRestriction.state.pstlStateAbbr.eq(ratingState).or(appRestriction.state.pstlStateAbbr.eq("CW")));
        }
        if(businessSegment != null){
        	 conditions.and(appRestriction.businessSegment.eq(businessSegment).or(appRestriction.businessSegment.isNull()));
        }
        if(partner != null){
        	 conditions.and(appRestriction.partner.eq(partner).or(appRestriction.partner.isNull()));
        }
        if(operationName != null){
        	 conditions.and(appRestriction.operationName.eq(operationName).or(appRestriction.operationName.isNull()));
        }
        if(producerCode != null){
         	 conditions.and(appRestriction.producerCode.eq(Long.parseLong(producerCode)).or(appRestriction.producerCode.isNull()));
        }
        if(lob != 0){
        	 conditions.and(appRestriction.lob.eq(lob));
        }
	}

	
}
