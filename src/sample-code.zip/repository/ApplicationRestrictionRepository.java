/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/
/**
 * @author AW94020
 */
package com.thehartford.pl.mr.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.thehartford.pl.mr.entity.ApplicationRestriction;




/**
 * Functional Interface for Database Repository Interactions
 *
 */
@Repository
@Transactional
@FunctionalInterface
public interface ApplicationRestrictionRepository {
	/**
	 * Method used to query ApplicationRestriction table.
	 * @param businessSegment
	 * @param partner
	 * @param operationName
	 * @param ratingState
	 * @param producerCode
	 * @param lob
	 * @param formType
	 * @return List of ApplicationRestriction objects matching query parameters 
	 *
	 */
    List<ApplicationRestriction> findByQuery(String businessSegment, String partner, String operationName,
            String ratingState, String producerCode, int lob, String formType);
			
}
