/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/
package com.thehartford.pl.mr.proxy.mapper;

public final class Mappers {

    public static final PersPkgMapper PERS_PKG_MAPPER = org.mapstruct.factory.Mappers.getMapper(PersPkgMapper.class);

    private Mappers() {
        //
    }
}
