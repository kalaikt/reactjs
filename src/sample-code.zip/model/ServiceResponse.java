/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for wrapping responses from service calls
 * holding response data and status.
 *
 * @param <T>
 */
public class ServiceResponse<T> implements Response<T> {

	private String status;
	private T data;
	private List<T> exceptions;

	/**
	 * Default constructor
	 */
	public ServiceResponse() {
		//
	}

	/**
	 * Set data object
	 * @param data
	 */
	@Override
	public void setData(T data) {
		this.data = data;
	}


	/**
	 * Get data object
	 * @return
	 */
	@Override
	public T getData() {
		return data;
	}


	/**
	 * Get status text
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Set status text
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public List<T> getExceptions() {
		return new ArrayList<>(exceptions);
	}

	public void setExceptions(List<T> exceptions) {
		if(exceptions != null){
			this.exceptions = new ArrayList<>(exceptions);
		}
	}

}
