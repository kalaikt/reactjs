/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ERROR_LOG")
public class ErrorLog implements Serializable {
	
	/**
	 * Version Id for serialization
	 */
	private static final long serialVersionUID = 7446206196236002821L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "ERROR_LOG_SEQ")
	@SequenceGenerator(name = "ERROR_LOG_SEQ", sequenceName = "ERROR_LOG_SEQ", allocationSize =1 )
	@Column(name = "ERR_LOG_PK_ID")
	private Long errorEntryId;

	@Column(name = "RQST_GID", length = 100)
	private String requestId;
	
	@Column(name = "TRANS_DT")
	private Date transactionDate;

	@Column(name = "TRANS_TYP", length = 20)
	private String transactionType;
	
	@Column(name = "TCN", length = 40)
	private String tcn;
	
	@Column(name = "LOI_ID")
	private Integer loiId;
	
	@Column(name = "STATE_CD")
	private int stateCode;
	
	@Column(name = "PRODR_CD")
	private String producerCode;
	
	@Column(name = "ERR_TYP")
	private String errorType;
	
	@Column(name = "ERR_CD")
	private String errorCode;
	
	@Column(name = "ERR_MSG")
	private String errorMessage;
	
	@Column(name = "ERR_SVRTY")
	private String errorSeverity;
	
	@Column(name = "VEND_ID")
	private String vendorSource;
	
	@Column(name = "USER_ID")
	private String userId;

	public ErrorLog() {
		// Default Constructor
	}

	public Long getErrorEntryId() {
		return errorEntryId;
	}

	public void setErrorEntryId(Long errorEntryId) {
		this.errorEntryId = errorEntryId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Date getTransactionDate() {
		if(transactionDate != null){
			return (Date) transactionDate.clone();
		}
		return null;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = (Date) transactionDate.clone();
	}
	
	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public String getTcn() {
		return tcn;
	}

	public void setTcn(String tcn) {
		this.tcn = tcn;
	}
	
	public Integer getLoiId() {
		return loiId;
	}

	public void setLoiId(Integer loiId) {
		this.loiId = loiId;
	}
	
	public int getStateCode() {
		return stateCode;
	}

	public void setStateCode(int stateCode) {
		this.stateCode = stateCode;
	}
	
	public String getProducerCode() {
		return producerCode;
	}

	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	
	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getErrorSeverity() {
		return errorSeverity;
	}

	public void setErrorSeverity(String errorSeverity) {
		this.errorSeverity = errorSeverity;
	}
	
	public String getVendorSource() {
		return vendorSource;
	}

	public void setVendorSource(String vendorSource) {
		this.vendorSource = vendorSource;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}