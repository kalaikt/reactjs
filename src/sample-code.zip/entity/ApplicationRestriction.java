/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name = "APP_RESTRICTION_CONTROL")
public class ApplicationRestriction implements Serializable {
	
	/**
	 * Version Id for serialization
	 */
	
	private static final long serialVersionUID = -269631892761438284L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "APP_RESTRICTION_CONTROL_SEQ")
	@SequenceGenerator(name = "APP_RESTRICTION_CONTROL_SEQ", sequenceName = "APP_RESTRICTION_CONTROL_SEQ", allocationSize =1 )
	@Column(name = "APPL_RSTRC_CTRL_PK_ID", insertable = false, updatable = false)
	private Long applRstrcId;

	@Column(name = "INSRT_DT")
	private Date insertDate = new Date();
	
	@Column(name = "EFF_DT")
	private Date effectiveDate;
	
	@Column(name = "BU_CD", length=20)
	private String businessSegment;
	
	@Column(name = "VEND_SRCE")
	private String partner;
	
	@Column(name = "OPER_NM")
	private String operationName;
	
	@Column(name = "LOI_ID")
	private int lob;
		
	@Column(name = "STATE_CD", nullable=false)
	private int ratingState;
	
	@Column(name = "PRODR_CD", length = 8)
	private Long producerCode;
	
	@Column(name = "SHUT_OFF_COMPNT", length = 5)
	private String shutOffCompnt;
	
	@Column(name = "RSTRC_FORM_TYP_HO3", length = 1)
	private String rstrcFormTypeHO3;
	
	@Column(name = "RSTRC_FORM_TYP_HO4", length = 1)
	private String rstrcFormTypeHO4;
	
	@Column(name = "RSTRC_FORM_TYP_HO5", length = 1)
	private String rstrcFormTypeHO5;
	
	@Column(name = "RSTRC_FORM_TYP_HO6", length = 1)
	private String rstrcFormTypeHO6;
	
	@Column(name = "RSTRC_FORM_TYP_HO7", length = 1)
	private String rstrcFormTypeHO7;
	
	@Column(name = "RSTRC_FORM_TYP_RP3")
	private String rstrcFormTypeRP3;
	
	@ManyToOne(optional=false)
	@JoinColumn(name="STATE_CD", referencedColumnName="STATE_CD", insertable=false, updatable=false)
    private StateEntity state;
	
	/**
     * No args constructor for use in serialization
     * 
     */
	public ApplicationRestriction(){
		//Default Constructor
	}
	
	public StateEntity getState() {
		return state;
	}

	public void setState(StateEntity state) {
		this.state = state;
	}

	public Long getApplRstrcId() {
		return applRstrcId;
	}

	public void setApplRstrcId(Long applRstrcId) {
		this.applRstrcId = applRstrcId;
	}

	public Date getInsertDate() {
		if(insertDate != null){
			return (Date) insertDate.clone();
		}
		return null;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = (Date) insertDate.clone();
	}

	public Date getEffectiveDate() {
		if(effectiveDate != null){
			return (Date) effectiveDate.clone();
		}
		return null;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = (Date) effectiveDate.clone();
	}

	public String getBusinessSegment() {
		return businessSegment;
	}

	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	
	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}
	
	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public int getLob() {
		return lob;
	}

	public void setLob(int lob) {
		this.lob = lob;
	}

	public int getRatingState() {
		return ratingState;
	}

	public void setRatingState(int ratingState) {
		this.ratingState = ratingState;
	}

	public Long getProducerCode() {
		return producerCode;
	}

	public void setProducerCode(Long producerCode) {
		this.producerCode = producerCode;
	}
	
	public String getShutOffCompnt() {
		return shutOffCompnt;
	}
	
	public void setShutOffCompnt(String shutOffCompnt) {
		this.shutOffCompnt = shutOffCompnt;
	}
	
	public String getRstrcFormTypeHO3() {
		return rstrcFormTypeHO3;
	}
	
	public void setRstrcFormTypeHO3(String rstrcFormTypeHO3) {
		this.rstrcFormTypeHO3 = rstrcFormTypeHO3;
	}
	
	public String getRstrcFormTypeHO4() {
		return rstrcFormTypeHO4;
	}
	
	public void setRstrcFormTypeHO4(String rstrcFormTypeHO4) {
		this.rstrcFormTypeHO4 = rstrcFormTypeHO4;
	}
	
	public String getRstrcFormTypeHO5() {
		return rstrcFormTypeHO5;
	}
	
	public void setRstrcFormTypeHO5(String rstrcFormTypeHO5) {
		this.rstrcFormTypeHO5 = rstrcFormTypeHO5;
	}
	
	public String getRstrcFormTypeHO6() {
		return rstrcFormTypeHO6;
	}
	
	public void setRstrcFormTypeHO6(String rstrcFormTypeHO6) {
		this.rstrcFormTypeHO6 = rstrcFormTypeHO6;
	}
	
	public String getRstrcFormTypeHO7() {
		return rstrcFormTypeHO7;
	}

	public void setRstrcFormTypeHO7(String rstrcFormTypeHO7) {
		this.rstrcFormTypeHO7 = rstrcFormTypeHO7;
	}
	
	public String getRstrcFormTypeRP3() {
		return rstrcFormTypeRP3;
	}
	
	public void setRstrcFormTypeRP3(String rstrcFormTypeRP3) {
		this.rstrcFormTypeRP3 = rstrcFormTypeRP3;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
