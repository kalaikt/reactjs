/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.proxy.clue;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import org.acord.standards.pc_surety.acord1_10_0.xml.PersPkgPolicyQuoteInqRqType;
import org.apache.wss4j.dom.WSConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;
import org.springframework.xml.transform.StringSource;

import com.thehartford.pl.mr.proxy.common.CommonInterceptor;
import com.thehartford.pl.mr.proxy.fs.FsProxyClient;
import com.thehartford.ws.pi.homequote.v1_0.types.ObjectFactory;
import com.thehartford.ws.pi.homequote.v1_0.types.OrderReport;
import com.thehartford.ws.pi.homequote.v1_0.types.OrderReportResponse;

@Service
public class ClueProxyClient extends FsProxyClient {
	private static final Logger LOG = LoggerFactory.getLogger(ClueProxyClient.class);
	
	@Value("${services.fs.clue.uri}")
    private String clueUri;

    @Autowired
    private ClueClientInterceptor interceptor;
    
    @Value("${services.fs.agency.username}")
	private String userName;

	@Value("${services.fs.agency.password}")
	private String password;
	
	private ObjectFactory objectFactory = new ObjectFactory();
    
    public ClueProxyClient(){
    	// default
    }
    
    /**
     * Sends a request to the Clue soap service
     *
     * @param request
     * @return
     */
    public OrderReportResponse call(PersPkgPolicyQuoteInqRqType persPkgPolicyQuoteInqRq) {
    	setDefaultUri(clueUri);
		setMarshaller(jaxb2Marshaller());
		setUnmarshaller(jaxb2Marshaller());
		
		interceptor.setRequestName("CLUE");
		
		OrderReport orderReport = objectFactory.createOrderReport();
		orderReport.setPersPkgPolicyQuoteInqRq(persPkgPolicyQuoteInqRq);
		
		return (OrderReportResponse) getWebServiceTemplate()
				.marshalSendAndReceive(orderReport, message -> {
							try {
								// soap message header
								SoapMessage soapMessage = (SoapMessage) message;
								SoapHeader header = soapMessage.getSoapHeader();
								StringSource headerSource = new StringSource(
										"<AppInfo xmlns=\"urn:com.thehartford.cto.headers.2006.01\">\n" + "<ContractId>"
												+ "4339" + "</ContractId>\n" + "</AppInfo>");
								// Using Transfomer to add the above headers to
								// the xml
								Transformer transformer = TransformerFactory.newInstance().newTransformer();
								transformer.transform(headerSource, header.getResult());
							} catch (Exception e) {
								LOG.error("Exception :)  occured while adding soap header element", e);
							}
						});
    }
    
	private void setWebsecurityInterceptor(Wss4jSecurityInterceptor wss4jSecurityInterceptor) {

		wss4jSecurityInterceptor.setSecurementActions("UsernameToken");
		wss4jSecurityInterceptor.setSecurementUsername(userName);
		wss4jSecurityInterceptor.setSecurementPassword(password);
		wss4jSecurityInterceptor.setSecurementPasswordType(WSConstants.PW_TEXT);

	}
	
    @Override
    public void addInterceptors() {
    	Wss4jSecurityInterceptor wss4jSecurityInterceptor = new Wss4jSecurityInterceptor();
    	setWebsecurityInterceptor(wss4jSecurityInterceptor);

		ClientInterceptor[] interceptors = new ClientInterceptor[] { wss4jSecurityInterceptor, interceptor };
		setInterceptors(interceptors);
    }

    @Override
    public CommonInterceptor getLoggingInterceptor() {
        return interceptor;
    }
}
