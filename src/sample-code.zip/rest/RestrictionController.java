/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/
package com.thehartford.pl.mr.admin.rest;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thehartford.pl.mr.admin.entity.ApplicationRestriction;
import com.thehartford.pl.mr.admin.models.ErrorMessage;
import com.thehartford.pl.mr.admin.models.Response;
import com.thehartford.pl.mr.admin.models.RestrictionRequest;
import com.thehartford.pl.mr.admin.repository.ApplicationRestrictionRepository;
/**
 * Controller designed to handle requests
 * to query ApplicationRestriction table
 * @author AC12459
 * @author AW94020
 * */
@RestController
@RequestMapping("/restrictions")
public class RestrictionController {

	private static final Logger LOG = LogManager.getLogger(RestrictionController.class);
	private static final int HTTP_STATUS_CODE_500 = 500;
	
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	@Autowired
	private ApplicationRestrictionRepository appRestriction;
	
	@PersistenceContext
	private EntityManager em;
	
	/**
	 *   Accepts a GET request and returns a list of all restrictions 
	  currently in the DB.  Uses the response class to generate a JSON
	  representation of the list for the responses
	 * @return response object containing the data
	 * */
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<ApplicationRestriction> defaultHandler() {
		LOG.info("Get all restriction");
		Response<ApplicationRestriction> response = new Response<>();
		response.setData(appRestriction.findAll(new Sort(Sort.Direction.DESC, "applRstrcId")));
		response.setError(null);
		return response;
	}
	
	/**
	 *   Used to add restrictions to the database. Accepts
	 a list of restrictions and adds each one.
	 * @param restrictions the list to be added of type RestrictionRequest
	 * @return response object that indicates whether or not
	 the data was added to the database.  
	 * */
	
	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<ApplicationRestriction> addRestriction(@RequestBody List<RestrictionRequest> restrictions) {
		LOG.info("Add Resctriction");

		Response<ApplicationRestriction> response = new Response<>();

		for (RestrictionRequest restriction : restrictions) {
			LOG.info(restriction.getBusinessSegment() + " " + restriction.getFormType());
			ApplicationRestriction newRstrc = new ApplicationRestriction();

			try { 
				newRstrc.setBusinessSegment(restriction.getBusinessSegment());
				newRstrc.setPartner(restriction.getPartner());
				newRstrc.setRatingState(restriction.getRatingState());
				newRstrc.setOperationName(restriction.getRateCall());
				newRstrc.setLob(restriction.getLob());
				newRstrc.setProducerCode(restriction.getProducerCode());
				newRstrc.setEffectiveDate(restriction.getEffectiveDate());
				newRstrc.setRstrcFormTypeHO3(restriction.getHo3());
				newRstrc.setRstrcFormTypeHO4(restriction.getHo4());
				newRstrc.setRstrcFormTypeHO5(restriction.getHo5());
				newRstrc.setRstrcFormTypeHO6(restriction.getHo6());

				appRestriction.save(newRstrc);

				response.setData(null);
				response.setError(null);
			} catch (Exception e) {
				ErrorMessage message = new ErrorMessage();

				message.setCode(HTTP_STATUS_CODE_500);
				message.setMessage("Fail to insert please check the data.");
				response.setError(message);
				LOG.error(e.getMessage(), e);
			}

		}

		return response;
	}

	/**
	 *   Accepts a single id and deletes the record in
	 the database based on this id
	 * @param id 
	 * @return response indicating if deletion was successful 
	 * */
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<ApplicationRestriction> deleteRestriction(@PathVariable long id) {
		Response<ApplicationRestriction> response = new Response<>();

		if (appRestriction.exists(id)) {
			appRestriction.delete(id);
			response.setData(null);
			response.setError(null);
		} else {

			ErrorMessage message = new ErrorMessage();

			message.setCode(HTTP_STATUS_CODE_500);
			message.setMessage("ID "+ id + " does not found.");

			response.setError(message);
			LOG.info(id + " does not exist.");
		}

		return response;
	}
}
