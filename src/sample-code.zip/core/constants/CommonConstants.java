/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.core.constants;

import java.util.stream.Stream;

public class CommonConstants {

    // Environment Property Keys
    public static final String AUTHORIZATION_CHECK_HEADER = "bypassAuthorizationCheck";
    public static final String AUTHORIZATION_CHECK_IND = "security.authorizationCheck.enabled";
    public static final String TEST_PROCESSING_STAGE_CD = "TestProcessingStageCd";
    public static final String CREDIT_SCORE = "CreditScore";
    public static final String SUCCESS_WITH_INFO = "SuccessWithInfo";

    public static final String CURRENCY_USD = "USD";
    // from contract number
    public static final int MARKETING_CD_START_INDEX = 2;

    // Type Codes
    public static final String OCCUPANCY_TENANT = "TENAN";

    // RP3 = 03 + Occupancy Tenant
    public enum FormType {
        HO3,
        HO4,
        HO5,
        HO6,
        HO7,
        RP3
        ;
    }
    
    public enum LOBCodes {
        HOME(2),
        AUTO(1);

        private int code;
        LOBCodes(int code) {
            this.code = code;
        }

        public int code() {
            return this.code;
        }

        public static Integer code(String name) {
            return Stream.of(LOBCodes.values())
                    .filter(t -> t.name().equalsIgnoreCase(name))
                    .map(LOBCodes::code)
                    .findFirst().orElse(null);
        }

        public static String name(int code) {
            return Stream.of(LOBCodes.values())
                    .filter(t -> t.code() == code)
                    .map(LOBCodes::name)
                    .findFirst().orElse(null);
        }

    }

    public enum MsgStatus {
        SUCCESS
        ;
    }
}
