/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.core;

import com.thehartford.pl.mr.core.context.RequestMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

public final class RequestContext {

    private static final Logger LOG = LoggerFactory.getLogger(RequestContext.class);
    private static final ThreadLocal<Long> localThreadId = new ThreadLocal<>();
    private static final ThreadLocal<String> localRequestId = new ThreadLocal<>();
    private static final ThreadLocal<String> localTCN = new ThreadLocal<>();
    private static final ThreadLocal<String> localRequestAction = new ThreadLocal<>();
    private static final ThreadLocal<String> localUserId = new ThreadLocal<>();
    private static final ThreadLocal<Integer> localLob = new ThreadLocal<>();
    private static final ThreadLocal<Object> localRequestData = new ThreadLocal<>();
    private static final ThreadLocal<CompletableFuture<Long>> localContractId = new ThreadLocal<>();
    private static final ThreadLocal<RequestMetadata> localRequestMetadata = ThreadLocal.withInitial(RequestMetadata::new);



	/**
	 * Private constructor to avoid object creation. Class contains all static
	 * fields and methods.
	 */
	private RequestContext() {
		// No-Arg constructor
	}

    public static void setThreadId(Long threadId) {
        localThreadId.set(threadId);
    }

    public static Long getThreadId() {
        return localThreadId.get();
    }

    public static void setTCN(String tcn) {
        localTCN.set(tcn);
    }

    public static String getTCN() {
        return localTCN.get();
    }

    public static void setRequestId(String requestId) {
        localRequestId.set(requestId);
    }

    public static String getRequestId() {
        return localRequestId.get();
    }
    
    public static void setRequestAction(String requestAction) {
    	localRequestAction.set(requestAction);
    }

    public static String getRequestAction() {
        return localRequestAction.get();
    }
    
    public static void setUserId(String userId) {
    	localUserId.set(userId);
    }

    public static String getUserId() {
        return localUserId.get();
    }
    
    public static void setLob(Integer lob) {
    	localLob.set(lob);
    }

    public static Integer getLob() {
        return localLob.get();
    }
    
    public static void setRequestData(Object requestData) {
        localRequestData.set(requestData);
    }

    @SuppressWarnings("unchecked")
	public static <T> T getRequestData() {
        return (T) localRequestData.get();
    }

    public static void setContractId(CompletableFuture<Long> id) {
	    if (getContractId() != null) {
	        LOG.error("Contract Id already set for this context...");
        }
        localContractId.set(id);
    }

    public static CompletableFuture<Long> getContractId() {
	    return localContractId.get();
    }

    public static RequestMetadata getRequestMetadata() {
        return localRequestMetadata.get();
    }

    public static void clear() {
        localThreadId.remove();
        localRequestId.remove();
        localTCN.remove();
        localRequestData.remove();
        localContractId.remove();
        localRequestMetadata.remove();
        localRequestAction.remove();
        localLob.remove();
    }


    public static String asString() {
        return String.format("threadId: %d%n requestId: %s%n tcn: %s%n  metadata: %s%n requestAction: %s%n LOB: %d",
                localThreadId.get(),
                localRequestId.get(),
                localTCN.get(),
                localRequestMetadata.get(),
                localRequestAction.get(),
                localLob.get());
    }
}
