/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.core.context;

import com.thehartford.pl.mr.entity.HomeEndorsementCustomEntity;

import java.util.ArrayList;
import java.util.List;

public class RequestMetadata {

	private String ratingState;
	private String formType;
	private String ratePlan;
	private String ratePlanPhaseCd;
	private String testCreditScore;
	private String testProcessingStageCd;
	private int stateCode;
	private String producerCode;
	private String vendorSource;
	private String action;
	private List<HomeEndorsementCustomEntity> customEntities;

	/**
	 * No-arg constructor
	 */
	public RequestMetadata() {
		// No-arg constructor
	}

	public String getRatingState() {
		return ratingState;
	}

	public void setRatingState(String ratingState) {
		this.ratingState = ratingState;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}

	public String getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	public String getRatePlanPhaseCd() {
		return ratePlanPhaseCd;
	}

	public void setRatePlanPhaseCd(String ratePlanPhaseCd) {
		this.ratePlanPhaseCd = ratePlanPhaseCd;
	}

	public String getTestProcessingStageCd() {
		return testProcessingStageCd;
	}

	public void setTestProcessingStageCd(String testProcessingStageCd) {
		this.testProcessingStageCd = testProcessingStageCd;
	}

	public String getTestCreditScore() {
		return testCreditScore;
	}

	public void setTestCreditScore(String testCreditScore) {
		this.testCreditScore = testCreditScore;
	}

	public int getStateCode() {
		return stateCode;
	}

	public void setStateCode(int stateCode) {
		this.stateCode = stateCode;
	}

	public String getProducerCode() {
		return producerCode;
	}

	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}

	public String getVendorSource() {
		return vendorSource;
	}

	public void setVendorSource(String vendorSource) {
		this.vendorSource = vendorSource;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the customEntities
	 */
	public List<HomeEndorsementCustomEntity> getCustomEntities() {
		if (customEntities == null) {
			customEntities=new ArrayList<>();
		}
		return customEntities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RequestMetadata [ratingState=");
		builder.append(ratingState);
		builder.append(", formType=");
		builder.append(formType);
		builder.append(", ratePlan=");
		builder.append(ratePlan);
		builder.append(", ratePlanPhaseCd=");
		builder.append(ratePlanPhaseCd);
		builder.append(", testProcessingStageCd=");
		builder.append(testProcessingStageCd);
		builder.append(", stateCode=");
		builder.append(stateCode);
		builder.append(", producerCode=");
		builder.append(producerCode);
		builder.append(", vendorSource=");
		builder.append(vendorSource);
		builder.append(", action=");
		builder.append(action);
		builder.append(customEntities);
		builder.append("]");
		return builder.toString();
	}
}
