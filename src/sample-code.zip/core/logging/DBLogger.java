/*
* Copyright (c) The Hartford Financial Services Group, Inc. 690 Asylum Ave, Hartford,
* Connecticut, 06155, U.S.A. All rights reserved.
*
* This software is the confidential and proprietary information of The Hartford Financial Services
* Group ("Confidential Information"). You shall not disclose such Confidential Information and
* shall use it only in accordance with the terms of the license agreement you entered into with The
* Hartford Financial Services Group.
*
*/

package com.thehartford.pl.mr.core.logging;

import com.thehartford.pl.mr.core.RequestContext;
import com.thehartford.pl.mr.core.SharedForkJoinPool;
import com.thehartford.pl.mr.entity.ErrorLog;
import com.thehartford.pl.mr.entity.ServiceLog;
import com.thehartford.pl.mr.repository.ErrorLogRepository;
import com.thehartford.pl.mr.repository.ServiceLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.util.Date;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
public class DBLogger {

	@Autowired
	private ServiceLogRepository serviceLogRepository;
	
	@Autowired
	private ErrorLogRepository errorLogRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(DBLogger.class);

	private static final String EXCEPTIONSTR = "Exception caught while logging in DB:";

	public DBLogger() {
		// Default Constructor
	}

	/**
	 * Method to log request and response in APPLICATION_LOG table
	 *@param requestId
	 *@param serviceName
	 *@param tcn
	 *@param requestData
	 */
	public CompletableFuture<Long> logRequest(
			String requestId,
			String serviceName, 
			String tcn, 
			String requestData) {

		String parentRequestId = RequestContext.getRequestId();

		return CompletableFuture.supplyAsync(() -> {
			LOGGER.info("async [executor: {}, thread: {}] - Logging Request into DB: [service:{}, reqid:{}, tcn:{}]",
					Thread.currentThread().getName(), Thread.currentThread().getId(), serviceName, requestId, tcn);

			ServiceLog serviceLog = saveServiceLogDetails(requestId, serviceName, tcn, requestData, parentRequestId);

			LOGGER.info("Saved service log [log id: {}]", serviceLog.getAppLogId());

			return serviceLog.getAppLogId();
		}, SharedForkJoinPool.loggerPool);
	}

	/**
	 * This method is used to save request info in ServiceLog table and returns
	 * ServiceLog object with id.
	 * 
	 * @param requestId
	 * @param serviceName
	 * @param tcn
	 * @param requestData
	 * @param parentRequestId
	 * @return {@link ServiceLog}
	 */
	private ServiceLog saveServiceLogDetails(String requestId, String serviceName, String tcn, String requestData,
			String parentRequestId) {
		ServiceLog serviceLog = new ServiceLog();
		try {
			serviceLog.setInsertDate(new Timestamp(System.currentTimeMillis()));
			serviceLog.setRequestId(requestId);
			serviceLog.setServiceName(serviceName);
			serviceLog.setTcn(transformTCN(tcn));
			serviceLog.setRequestStartTime(new Timestamp(new Date().getTime()));
			serviceLog.setRequestData(requestData);
			serviceLog.setParentRequestId(parentRequestId);

			this.serviceLogRepository.save(serviceLog);

		} catch (Exception ex) {
			LOGGER.error(EXCEPTIONSTR, ex.getMessage(), ex);
		}

		return serviceLog;
	}

	/**
	 * Method to log response in APPLICATION_LOG table
	 * 
	 * @param appLogId
	 * @param responseData
	 * @param statLevel
	 */
	public void updateResponse(CompletableFuture<Long> appLogId, String responseData, String statLevel) {
		CompletableFuture.runAsync(() -> {
			try {
				Long id = appLogId.get();
				if (id.intValue() > 0) {
					updateResponseInServiceLog(appLogId, id, responseData, statLevel);
				}
			} catch (IllegalArgumentException |  ExecutionException | InterruptedException ex) {
				LOGGER.error(EXCEPTIONSTR, ex.getMessage(), ex);
				Thread.currentThread().interrupt(); 
			} 
		}, SharedForkJoinPool.loggerPool);
	}

	/**
	 * This method is used to update response in db in ServiceLog table.
	 * 
	 * @param appLogId
	 * @param id
	 * @param responseData
	 * @param statLevel
	 */
	private void updateResponseInServiceLog(CompletableFuture<Long> appLogId, Long id, String responseData,
			String statLevel) {
		ServiceLog serviceLog = this.serviceLogRepository.findById(id).orElse(null);

		if (serviceLog != null) {
			LOGGER.info(
					"async [executor: {}, thread: {}] - Updating Response into DB: [id:{}, service:{}, reqid:{}, tcn:{}, log id: {}]",
					Thread.currentThread().getName(), Thread.currentThread().getId(), appLogId,
					serviceLog.getServiceName(), serviceLog.getRequestId(), serviceLog.getTcn(), id);

			serviceLog.setResponseData(responseData);
			serviceLog.setRequestEndTime(new Timestamp(new Date().getTime()));
			serviceLog.setStatLevel(statLevel);

			this.serviceLogRepository.save(serviceLog);
		} else {
			LOGGER.error("Failed to find service log: [log id: {}]", id);
		}
	}


	/**
	 * Method is used to log errors.
	 * 
	 * @param errorLog
	 */
	public void logError(ErrorLog errorLog) {
		errorLog.setRequestId(RequestContext.getRequestId());
		errorLog.setTransactionDate(new Date());
		errorLog.setTransactionType(RequestContext.getRequestAction());
		errorLog.setTcn(RequestContext.getTCN());
		errorLog.setLoiId(RequestContext.getLob());
		errorLog.setStateCode(RequestContext.getRequestMetadata().getStateCode());
		errorLog.setProducerCode(RequestContext.getRequestMetadata().getProducerCode());
		
		String vendorName = RequestContext.getRequestMetadata().getVendorSource();
		
		if(!StringUtils.isEmpty(vendorName)){
			vendorName = vendorName.split("-")[0].trim();
		}
		
		errorLog.setVendorSource(vendorName);
		errorLog.setUserId(RequestContext.getUserId());
		
		try {
			this.errorLogRepository.save(errorLog);
			
		} catch (Exception ex) {
			LOGGER.error(EXCEPTIONSTR, ex.getMessage(), ex);
		}
	}

	protected String transformTCN(String tcn) {
		if (StringUtils.isEmpty(tcn)) {
			return "NA";
		}
		return tcn;
	}


	public void logError(String errorType, String errorCode, String errorMsg) {
		ErrorLog errorLog = new ErrorLog();
		errorLog.setErrorType(errorType);
		errorLog.setErrorCode(errorCode);
		errorLog.setErrorMessage(errorMsg);

        logError(errorLog);
	}

}
