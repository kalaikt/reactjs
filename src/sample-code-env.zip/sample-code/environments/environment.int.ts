
import { mock } from './mock.config';
import { endpoint } from './endpoint.config';

export const environment = {
  production: false,
  envName: "int",
  endpoint: Object.assign({baseUrl: ""},endpoint)
};
