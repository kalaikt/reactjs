

export const endpoint = {
  restriction: { path: "/restrictions", forceApi: false },
  addRestriction: { path: "/restrictions/add", forceApi: false },
  deleteRestriction: { path: "/restrictions/delete", forceApi: false },
  getPartners: { path: "/partners", forceApi: false },
  errorReport: { path: "/errorReport/find", forceApi: false },
  reqAndRes: { path: "/errorReport/reqAndRes", forceApi: false }
};
