import * as DEV from './environment';
import * as QA from './environment.qa';
import * as LTQ from './environment.ltq';
import * as PTE from './environment.pte';
import * as PROD from './environment.prod';
import * as LTI from './environment.lti';
import * as INT from './environment.int';
import * as LOCAL from './environment.local';
import * as TRAINING from './environment.training';

export class EnvironmentWrapper {

  /**/
  static getEnvironment(): any {
    const url = document.location.hostname;
    let env: any;

    if (url.includes('qa-')) {
      env = QA.environment;
    } else if (url.includes('ltq-')) {
      env = LTQ.environment;
    } else if (url.includes('pte-')) {
      env = PTE.environment;
    } else if (url.includes('lti-')) {
      env = LTI.environment;
    } else if (url.includes('int-')) {
      env = INT.environment;
    } else if (url.includes('prod-')) {
      env = PROD.environment;
    } else if (url.includes('localhost')) {
      env = LOCAL.environment;
    } else if (url.includes('training-')) {
      env = TRAINING.environment;
    } else {
      env = DEV.environment;
    }

    return env
  }
}
export let environment: any = EnvironmentWrapper.getEnvironment();
