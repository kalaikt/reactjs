// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { mock } from './mock.config';
import { endpoint } from './endpoint.config';

export const environment = {
  production: false,
  envName: "local",
  endpoint:{
    mock: mock,
    api: Object.assign({baseUrl: "http://localhost:8080/admin"},endpoint)
  }
};
