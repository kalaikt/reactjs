export const mock = {
  baseUrl: "./mock/",
  restriction: { path: "restrictions.json", forceApi: false },
  addRestriction: { path: "", forceApi: false },
  deleteRestriction: { path: "", forceApi: false },
  errorReport: { path: "", forceApi: false },
  reqAndRes: { path: "", forceApi: false }
};
